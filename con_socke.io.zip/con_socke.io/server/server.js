// Document js
const jwt = require('jsonwebtoken')
const express = require('express')
const app = express()
const http = require('http')
const server = http.createServer(app)
const { Server } = require("socket.io")
const cors = require('cors')
const io = new Server(server, {
    cors: {
        origin: "*",
        credentials: true
    }
})

app.use(cors())
app.use(express.json())
app.set('port', process.env.PORT || 4000)
app.use(express.urlencoded({extended: true}))

app.post('/register', (req, res) => {
    const user = {
        username: 'benjamin',
        password: '12345'
    }
    const token = jwt.sign( {user}, 'keysecret' )
    res.json({
        token, 
        user,
        validateEmail: false
    })
})

app.post('/user', verificarToken, (req, res) => {
    res.status(200)
})

app.post('/login', (req, res) => {
    const user = {
        username: 'benjamin',
        password: '12345'
    }
    const token = jwt.sign( {user}, 'keysecret' )
    res.json({
        token, 
        user,
        validateEmail: false
    })
})

function verificarToken(req, res, next) {
    const token = req.headers['authorization'].split(' ')[1];
    if( token ){
        jwt.verify(token,'keysecret', (err, data) => {
            if(err){
                return res.status(500).json({error: err})
            }
            res.status(200).json({
                token, 
                user: {...data.user, active: true},
                validateEmail: true
            })
            next()
        } )
    }
}

server.listen(app.get('port'), () => {
    console.log(`http://localhost:${app.get('port')}`)
})

var listUser = []
io.on('connection', (socket) => {
    socket.on('join', ({sessionID, name, photo, receiver, message}) => {
        socket.join(sessionID)
        
        if( listUser.filter(e => e.sessionID == sessionID).length === 0 ){
            listUser.push({sessionID, name, photo, receiver, message}) 
            socket.broadcast.emit('userConnected', name.trim())
        }
        io.emit('listUser', listUser)
    })
})