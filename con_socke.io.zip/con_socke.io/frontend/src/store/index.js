import { createStore } from 'vuex'

export default createStore({
    state: {
        dataUser: null,
        isAuthenticated: false
    },
    getters: {
        // get value autenticate
        isAuthenticated(state) {
            return state.isAuthenticated
        },
        // get data user
        getValidateEmail(state) {
            return state.dataUser.validateEmail
        },
        getUser(state) {
            return state.dataUser.user
        },
        getToken(state) {
            return state.dataUser.token
        },
    },
    mutations: {
        // state validate email 
        DataUser(state, value) {
            state.dataUser = value
        },

        // state autenticated
        AuthenticatedToTrue(state) {
            state.isAuthenticated = true
        },
        AuthenticatedToFalse(state) {
            state.isAuthenticated = false
        },
        AuthenticatedToggle(state) {
            state.isAuthenticated = !state.isAuthenticated
        },
    },
    actions: {
    },
    modules: {
    }
})
