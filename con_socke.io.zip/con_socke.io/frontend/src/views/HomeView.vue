<template>
    <h1>Home</h1>
    <button @click="cerrar">Cerrar</button>
    <!-- {{$store.getters.getToken}} -->
    <AvatarProfile />
</template>

<script>
import store from "@/store";
import { URL } from "@/helpers/urls";
import { io } from "socket.io-client";
import { useRouter } from "vue-router";

import AvatarProfile from '@/components/AvatarProfile.vue'

export default {
    name: "HomeView",
    components: {
        AvatarProfile
    },
    setup() {
        const router = useRouter();

        const socket = io(URL.server);
        socket.on("timestamp", (e) => {
            console.log(e);
        });

        if (store.getters.isAuthenticated) {
            router.push("/");
        }

        const cerrar = () => {
            store.commit("AuthenticatedToFalse");
            if (!store.getters.isAuthenticated) {
                router.push("/login");
                localStorage.removeItem("accessToken");
            }
        };

        return {
            cerrar,
        };
    },
};
</script>