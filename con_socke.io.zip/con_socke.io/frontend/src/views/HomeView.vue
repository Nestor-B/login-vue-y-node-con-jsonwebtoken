<template>
    <h1>Home</h1>
    <button @click="cerrar">Cerrar</button>
</template>

<script>
    import store from '@/store'
    import { useRouter } from 'vue-router'
    import { io } from "socket.io-client"
    
    const socket = io('http://localhost:4000')

    export default {
        name: 'HomeView',
        setup(){
            const router = useRouter()
            console.log(socket)

            if( store.getters.isAuthenticated ) {
                router.push('/')
            }

            const cerrar = () => {
                store.commit('AuthenticatedToFalse')
                if( !store.getters.isAuthenticated ) {
                    router.push('/login')
                    localStorage.removeItem('accessToken')
                }
            }

            return {
                cerrar
            }
        }
    }
</script>
