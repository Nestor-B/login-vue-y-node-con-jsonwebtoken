<template>
    <h1>Registro</h1>
    <router-link to="/login">Login</router-link>
    <button @click="register">Register</button>
</template>

<script>
    import store from '@/store'
    import { useRouter } from 'vue-router'
    import { URL } from '@/helpers/urls'

    export default {
        name: 'RegisterView',
        setup(){
            const router = useRouter()

            if( store.getters.isAuthenticated ) {
                router.push('/')
            }
            
            const register = () => {
                // Realizar registro
                fetch(`${URL.server}/register`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }).then((e) => e.json())
                .then((e) => {
                    if(e.token) {
                        store.commit('AuthenticatedToTrue')
                        localStorage.setItem('accessToken', JSON.stringify(e))
                        router.push('/verify-login')
                    }
                })
            }

            return {
                register
            }
        }
    }
</script>