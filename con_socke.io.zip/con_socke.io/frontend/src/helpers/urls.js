export const URL = {
    server: 'http://localhost:4000'
}